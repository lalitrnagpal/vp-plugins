package com.vp.plugin.sample.samplesequencediagram;

import com.vp.plugin.*;

public class GenerateSampleSequenceDiagramPlugin implements VPPlugin {
	
	public void loaded(VPPluginInfo aArg0) {
	}
	
	public void unloaded() {
	}

}
