package com.vp.plugin.aws.shape.database;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class RDSMySQLDBInstanceAlternateController extends SVGShapeController {
	
	public RDSMySQLDBInstanceAlternateController() {
		super("resources"+File.separator+"shape"+File.separator+"database"+File.separator+"RDSMySQLDBInstanceAlternate.svg");
	}
}
