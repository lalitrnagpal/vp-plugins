package com.vp.plugin.aws.shape.monitoring;

import com.vp.plugin.aws.shape.*;

public class ApplicationController extends SVGShapeController {

	public ApplicationController() {
		super("AWS_Simple_Icons_Deployment_Management_AWS_Elastic_BeanStalk_Applicaton.svg");
	}

}
