package com.vp.plugin.aws.shape.storage;

import com.vp.plugin.aws.shape.*;

public class BucketWithObjectsController extends SVGShapeController {

	public BucketWithObjectsController() {
		super("AWS_Simple_Icons_Storage_Amazon_S3_Bucket_with_Objects.svg");
	}

}
