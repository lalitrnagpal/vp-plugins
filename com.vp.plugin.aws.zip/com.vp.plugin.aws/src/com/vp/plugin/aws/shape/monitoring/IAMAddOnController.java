package com.vp.plugin.aws.shape.monitoring;

import com.vp.plugin.aws.shape.*;

public class IAMAddOnController extends SVGShapeController {

	public IAMAddOnController() {
		super("AWS_Simple_Icons_Deployment_Management_AWS_IAM_Add_on.svg");
	}

}
