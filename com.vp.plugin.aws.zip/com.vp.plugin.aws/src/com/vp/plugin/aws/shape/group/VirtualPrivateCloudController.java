package com.vp.plugin.aws.shape.group;

import java.awt.*;

import com.vp.plugin.aws.shape.*;

public class VirtualPrivateCloudController extends GroupShapeController {

	public VirtualPrivateCloudController() {
		super("VirtualPrivateCloud.png", new BasicStroke(1));
	}

}
