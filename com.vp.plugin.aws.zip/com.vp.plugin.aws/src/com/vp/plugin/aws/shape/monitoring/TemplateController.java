package com.vp.plugin.aws.shape.monitoring;

import com.vp.plugin.aws.shape.*;

public class TemplateController extends SVGShapeController {

	public TemplateController() {
		super("AWS_Simple_Icons_Deployment_Management_AWS_CloudFormation_Template.svg");
	}

}
