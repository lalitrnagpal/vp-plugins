package com.vp.plugin.aws.shape.enterpriseapplications;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class WorkDocsController extends SVGShapeController {
	
	public WorkDocsController() {
		super("resources"+File.separator+"shape"+File.separator+"enterpriseapplications"+File.separator+"WorkDocs.svg");
	}
}
