package com.vp.plugin.aws.shape.nonservicespecific;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class GenericDatabaseController extends SVGShapeController {
	
	public GenericDatabaseController() {
		super("resources"+File.separator+"shape"+File.separator+"nonservicespecific"+File.separator+"GenericDatabase.svg");
	}
}
