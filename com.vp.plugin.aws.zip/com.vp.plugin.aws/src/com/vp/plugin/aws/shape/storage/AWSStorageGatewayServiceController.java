package com.vp.plugin.aws.shape.storage;

import com.vp.plugin.aws.shape.*;

public class AWSStorageGatewayServiceController extends SVGShapeController {

	public AWSStorageGatewayServiceController() {
		super("AWS_Simple_Icons_Storage_AWS_Storage_Gateway.svg");
	}

}
