package com.vp.plugin.aws.shape.ondemandworkforce;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class WorkersController extends SVGShapeController {
	
	public WorkersController() {
		super("resources"+File.separator+"shape"+File.separator+"ondemandworkforce"+File.separator+"Workers.svg");
	}
}
