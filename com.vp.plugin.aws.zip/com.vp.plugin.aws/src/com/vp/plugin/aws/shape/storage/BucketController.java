package com.vp.plugin.aws.shape.storage;

import com.vp.plugin.aws.shape.*;

public class BucketController extends SVGShapeController {

	public BucketController() {
		super("AWS_Simple_Icons_Storage_Amazon_S3_Bucket.svg");
	}

}
