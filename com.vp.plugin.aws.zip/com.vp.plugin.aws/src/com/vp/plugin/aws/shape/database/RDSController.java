package com.vp.plugin.aws.shape.database;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class RDSController extends SVGShapeController {
	
	public RDSController() {
		super("resources"+File.separator+"shape"+File.separator+"database"+File.separator+"RDS.svg");
	}
}
