package com.vp.plugin.aws.shape.database;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class RDSDBInstanceStandbyController extends SVGShapeController {
	
	public RDSDBInstanceStandbyController() {
		super("resources"+File.separator+"shape"+File.separator+"database"+File.separator+"RDSDBInstanceStandby.svg");
	}
}
