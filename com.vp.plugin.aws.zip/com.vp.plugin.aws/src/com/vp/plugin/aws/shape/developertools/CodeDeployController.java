package com.vp.plugin.aws.shape.developertools;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class CodeDeployController extends SVGShapeController {
	
	public CodeDeployController() {
		super("resources"+File.separator+"shape"+File.separator+"developertools"+File.separator+"CodeDeploy.svg");
	}
}
