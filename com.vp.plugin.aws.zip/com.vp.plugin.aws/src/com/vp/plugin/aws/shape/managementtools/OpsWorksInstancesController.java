package com.vp.plugin.aws.shape.managementtools;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class OpsWorksInstancesController extends SVGShapeController {
	
	public OpsWorksInstancesController() {
		super("resources"+File.separator+"shape"+File.separator+"managementtools"+File.separator+"OpsWorksInstances.svg");
	}
}
