package com.vp.plugin.aws.shape.group;

import java.awt.*;

import com.vp.plugin.aws.shape.*;

public class AutoScalingGroupController extends GroupShapeController {

	public AutoScalingGroupController() {
		super(null, new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] {1, 3, 9, 3}, 0));
	}

}
