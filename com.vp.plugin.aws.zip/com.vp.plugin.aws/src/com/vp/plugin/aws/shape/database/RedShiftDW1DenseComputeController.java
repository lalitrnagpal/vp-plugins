package com.vp.plugin.aws.shape.database;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class RedShiftDW1DenseComputeController extends SVGShapeController {
	
	public RedShiftDW1DenseComputeController() {
		super("resources"+File.separator+"shape"+File.separator+"database"+File.separator+"RedShiftDW1DenseCompute.svg");
	}
}
