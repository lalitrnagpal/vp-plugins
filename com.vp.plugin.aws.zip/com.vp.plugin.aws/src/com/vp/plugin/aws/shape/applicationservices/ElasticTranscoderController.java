package com.vp.plugin.aws.shape.applicationservices;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class ElasticTranscoderController extends SVGShapeController {
	
	public ElasticTranscoderController() {
		super("resources"+File.separator+"shape"+File.separator+"applicationservices"+File.separator+"ElasticTranscoder.svg");
	}
}
