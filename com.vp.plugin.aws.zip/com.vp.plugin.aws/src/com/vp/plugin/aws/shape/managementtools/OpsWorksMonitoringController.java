package com.vp.plugin.aws.shape.managementtools;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class OpsWorksMonitoringController extends SVGShapeController {
	
	public OpsWorksMonitoringController() {
		super("resources"+File.separator+"shape"+File.separator+"managementtools"+File.separator+"OpsWorksMonitoring.svg");
	}
}
