package com.vp.plugin.aws.shape.group;

import java.awt.*;

import com.vp.plugin.aws.shape.*;

public class EC2InstanceContentsController extends GroupShapeController {

	public EC2InstanceContentsController() {
		super("EC2InstanceContents.png", new BasicStroke(1));
	}

}
