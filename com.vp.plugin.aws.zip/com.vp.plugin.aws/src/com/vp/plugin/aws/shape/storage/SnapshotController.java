package com.vp.plugin.aws.shape.storage;

import com.vp.plugin.aws.shape.*;

public class SnapshotController extends SVGShapeController {

	public SnapshotController() {
		super("AWS_Simple_Icons_Storage_Amazon_EBS_Snapshot.svg");
	}

}
