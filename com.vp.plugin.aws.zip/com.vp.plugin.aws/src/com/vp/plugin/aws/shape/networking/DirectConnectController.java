package com.vp.plugin.aws.shape.networking;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class DirectConnectController extends SVGShapeController {
	
	public DirectConnectController() {
		super("resources"+File.separator+"shape"+File.separator+"networking"+File.separator+"DirectConnect.svg");
	}
}
