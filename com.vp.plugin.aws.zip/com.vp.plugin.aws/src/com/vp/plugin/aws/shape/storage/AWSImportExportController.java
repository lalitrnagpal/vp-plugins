package com.vp.plugin.aws.shape.storage;

import com.vp.plugin.aws.shape.*;

public class AWSImportExportController extends SVGShapeController {

	public AWSImportExportController() {
		super("AWS_Simple_Icons_Storage_AWS_Import_Export.svg");
	}

}
