package com.vp.plugin.aws.shape.nonservicespecific;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class UsersController extends SVGShapeController {
	
	public UsersController() {
		super("resources"+File.separator+"shape"+File.separator+"nonservicespecific"+File.separator+"Users.svg");
	}
}
