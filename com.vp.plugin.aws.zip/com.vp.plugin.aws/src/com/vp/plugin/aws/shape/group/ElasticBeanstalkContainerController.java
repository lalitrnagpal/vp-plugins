package com.vp.plugin.aws.shape.group;

import java.awt.*;

import com.vp.plugin.aws.shape.*;

public class ElasticBeanstalkContainerController extends GroupShapeController {

	public ElasticBeanstalkContainerController() {
		super("ElasticBeanstalkContainer.png", new BasicStroke(1));
	}

}
