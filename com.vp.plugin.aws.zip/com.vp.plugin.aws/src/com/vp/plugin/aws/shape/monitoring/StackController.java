package com.vp.plugin.aws.shape.monitoring;

import com.vp.plugin.aws.shape.*;

public class StackController extends SVGShapeController {

	public StackController() {
		super("AWS_Simple_Icons_Deployment_Management_AWS_CloudFormation_Stack.svg");
	}

}
