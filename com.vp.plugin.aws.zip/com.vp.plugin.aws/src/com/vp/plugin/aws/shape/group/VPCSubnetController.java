package com.vp.plugin.aws.shape.group;

import java.awt.*;

import com.vp.plugin.aws.shape.*;

public class VPCSubnetController extends GroupShapeController {

	public VPCSubnetController() {
		super("VPCSubnet.png", new BasicStroke(1));
	}

}
