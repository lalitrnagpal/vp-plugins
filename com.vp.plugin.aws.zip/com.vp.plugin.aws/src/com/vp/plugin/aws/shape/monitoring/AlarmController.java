package com.vp.plugin.aws.shape.monitoring;

import com.vp.plugin.aws.shape.*;

public class AlarmController extends SVGShapeController {

	public AlarmController() {
		super("AWS_Simple_Icons_Monitoring_Amazon_CloudWatch_Alarm.svg");
	}

}
