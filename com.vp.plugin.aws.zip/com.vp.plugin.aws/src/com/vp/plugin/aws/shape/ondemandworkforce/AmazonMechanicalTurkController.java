package com.vp.plugin.aws.shape.ondemandworkforce;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class AmazonMechanicalTurkController extends SVGShapeController {
	
	public AmazonMechanicalTurkController() {
		super("resources"+File.separator+"shape"+File.separator+"ondemandworkforce"+File.separator+"AmazonMechanicalTurk.svg");
	}
}
