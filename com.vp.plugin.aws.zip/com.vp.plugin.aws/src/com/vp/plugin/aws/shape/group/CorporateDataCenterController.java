package com.vp.plugin.aws.shape.group;

import java.awt.*;

import com.vp.plugin.aws.shape.*;

public class CorporateDataCenterController extends GroupShapeController {

	public CorporateDataCenterController() {
		super("CorporateDataCenter.png", new BasicStroke(1));
	}

}
