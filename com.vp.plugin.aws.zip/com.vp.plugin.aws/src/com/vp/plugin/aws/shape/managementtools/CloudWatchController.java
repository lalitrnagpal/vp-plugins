package com.vp.plugin.aws.shape.managementtools;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class CloudWatchController extends SVGShapeController {
	
	public CloudWatchController() {
		super("resources"+File.separator+"shape"+File.separator+"managementtools"+File.separator+"CloudWatch.svg");
	}
}
