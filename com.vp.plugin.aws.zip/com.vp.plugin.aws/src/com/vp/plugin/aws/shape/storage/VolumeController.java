package com.vp.plugin.aws.shape.storage;

import com.vp.plugin.aws.shape.*;

public class VolumeController extends SVGShapeController {

	public VolumeController() {
		super("AWS_Simple_Icons_Storage_Amazon_EBS_Volume.svg");
	}

}
