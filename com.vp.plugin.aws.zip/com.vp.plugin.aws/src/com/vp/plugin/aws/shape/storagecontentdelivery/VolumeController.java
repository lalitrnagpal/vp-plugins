package com.vp.plugin.aws.shape.storagecontentdelivery;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class VolumeController extends SVGShapeController {
	
	public VolumeController() {
		super("resources"+File.separator+"shape"+File.separator+"storagecontentdelivery"+File.separator+"Volume.svg");
	}
}
