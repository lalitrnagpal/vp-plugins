package com.vp.plugin.aws.shape.ondemandworkforce;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class HumanIntelligenceTasksController extends SVGShapeController {
	
	public HumanIntelligenceTasksController() {
		super("resources"+File.separator+"shape"+File.separator+"ondemandworkforce"+File.separator+"HumanIntelligenceTasks.svg");
	}
}
