package com.vp.plugin.aws.shape.ondemandworkforce;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class AssignmentTaskController extends SVGShapeController {
	
	public AssignmentTaskController() {
		super("resources"+File.separator+"shape"+File.separator+"ondemandworkforce"+File.separator+"AssignmentTask.svg");
	}
}
