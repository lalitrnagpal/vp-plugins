package com.vp.plugin.aws.shape.monitoring;

import com.vp.plugin.aws.shape.*;

public class AmazonElasticBeanstalkController extends SVGShapeController {

	public AmazonElasticBeanstalkController() {
		super("AWS_Simple_Icons_Deployment_Management_AWS_Elastic_BeanStalk.svg");
	}

}
