package com.vp.plugin.aws.shape.database;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class ElastiCacheRedisController extends SVGShapeController {
	
	public ElastiCacheRedisController() {
		super("resources"+File.separator+"shape"+File.separator+"database"+File.separator+"ElastiCacheRedis.svg");
	}
}
