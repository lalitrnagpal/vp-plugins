package com.vp.plugin.aws.shape.nonservicespecific;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class CorporateDataCenterController extends SVGShapeController {
	
	public CorporateDataCenterController() {
		super("resources"+File.separator+"shape"+File.separator+"nonservicespecific"+File.separator+"CorporateDataCenter.svg");
	}
}
