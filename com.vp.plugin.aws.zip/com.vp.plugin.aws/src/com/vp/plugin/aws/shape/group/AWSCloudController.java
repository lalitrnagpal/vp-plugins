package com.vp.plugin.aws.shape.group;

import java.awt.*;

import com.vp.plugin.aws.shape.*;

public class AWSCloudController extends GroupShapeController {

	public AWSCloudController() {
		super("AWSCloud.png", new BasicStroke(1));
	}

}
