package com.vp.plugin.aws.shape.group;

import java.awt.*;

import com.vp.plugin.aws.shape.*;

public class RegionController extends GroupShapeController {

	public RegionController() {
		super(null, new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] {1, 1}, 0));
	}

}
