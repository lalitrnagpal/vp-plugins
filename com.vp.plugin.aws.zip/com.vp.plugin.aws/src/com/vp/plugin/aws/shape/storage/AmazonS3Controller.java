package com.vp.plugin.aws.shape.storage;

import com.vp.plugin.aws.shape.*;

public class AmazonS3Controller extends SVGShapeController {

	public AmazonS3Controller() {
		super("AWS_Simple_Icons_Storage_Amazon_S3.svg");
	}

}
