package com.vp.plugin.aws.shape.securityidentity;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class IdentityAccessManagementAWSSecurityTokenServiceController extends SVGShapeController {
	
	public IdentityAccessManagementAWSSecurityTokenServiceController() {
		super("resources"+File.separator+"shape"+File.separator+"securityidentity"+File.separator+"IdentityAccessManagementAWSSecurityTokenService.svg");
	}
}
