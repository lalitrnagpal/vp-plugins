package com.vp.plugin.aws.shape.managementtools;

import com.vp.plugin.aws.shape.*;
import java.io.*;

public class OpsWorksResourcesController extends SVGShapeController {
	
	public OpsWorksResourcesController() {
		super("resources"+File.separator+"shape"+File.separator+"managementtools"+File.separator+"OpsWorksResources.svg");
	}
}
