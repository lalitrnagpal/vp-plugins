package com.vp.plugin.aws.shape.storage;

import com.vp.plugin.aws.shape.*;

public class AmazonGlacierController extends SVGShapeController {

	public AmazonGlacierController() {
		super("AWS_Simple_Icons_Amazon_Glacier.svg");
	}

}
