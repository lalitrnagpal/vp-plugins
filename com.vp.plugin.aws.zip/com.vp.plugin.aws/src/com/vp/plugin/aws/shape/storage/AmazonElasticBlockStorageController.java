package com.vp.plugin.aws.shape.storage;

import com.vp.plugin.aws.shape.*;

public class AmazonElasticBlockStorageController extends SVGShapeController {

	public AmazonElasticBlockStorageController() {
		super("AWS_Simple_Icons_Storage_Amazon_EBS.svg");
	}

}
