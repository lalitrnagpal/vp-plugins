package com.vp.plugin.aws.shape.monitoring;

import com.vp.plugin.aws.shape.*;

public class AWSIAMController extends SVGShapeController {

	public AWSIAMController() {
		super("AWS_Simple_Icons_Deployment_Management_AWS_IAM.svg");
	}

}
