package com.vp.plugin.sample.samplecommunicationdiagram;

import com.vp.plugin.*;

public class GenerateSampleCommunicationDiagramPlugin implements VPPlugin {

	public void loaded(VPPluginInfo aArg0) {
	}

	public void unloaded() {
	}

}
