package com.vp.plugin.sample.diagramtoolbar;

import com.vp.plugin.*;

public class DiagramToolbarButtonPlugin implements VPPlugin {

	public void loaded(VPPluginInfo aArg0) {
	}

	public void unloaded() {
	}

}
