package sample.genflowofevents;

import com.vp.plugin.VPPlugin;
import com.vp.plugin.VPPluginInfo;

public class GenFlowOfEvents implements VPPlugin{

	public void loaded(VPPluginInfo pluginInfo) {
	}

	public void unloaded() {
	}

}
